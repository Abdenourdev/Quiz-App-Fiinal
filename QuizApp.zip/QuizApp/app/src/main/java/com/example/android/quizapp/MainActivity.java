package com.example.android.quizapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    int totalQuestions =5;
    int totalCorectAnswers=0;
    int nomberCheckBoxTrue = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    // set radioButton question 1 answer 1 true
    public void radioButtonQuestion1Answer1(View view){
        RadioButton radioButtonQuestion1Answer1 = findViewById(R.id.rb_question1_answer1);
        radioButtonQuestion1Answer1.setChecked(true);
    }
    // set radioButton question 1 answer 2 true
    public void radioButtonQuestion1Answer2(View view){
        RadioButton radioButtonQuestion1Answer2 = (RadioButton) findViewById(R.id.rb_question1_answer2);
        radioButtonQuestion1Answer2.setChecked(true);
    }
    // set radioButton question 1 answer 3 true
    public void radioButtonQuestion1Answer3(View view){
        RadioButton radioButtonQuestion1Answer3 = (RadioButton) findViewById(R.id.rb_question1_answer3);
        radioButtonQuestion1Answer3.setChecked(true);
    }
    // set radioButton question 1 answer 4 true
    public void radioButtonQuestion1Answer4(View view){
        RadioButton radioButtonQuestion1Answer4 = (RadioButton) findViewById(R.id.rb_question1_answer4);
        radioButtonQuestion1Answer4.setChecked(true);
    }
    // set radioButton question 4 answer 1 true
    public void radioButtonQuestion4Answer1(View view){
        RadioButton radioButtonQuestion4Answer1 = findViewById(R.id.rb_question4_answer1);
        radioButtonQuestion4Answer1.setChecked(true);
    }
    // set radioButton question 4 answer 2 true
    public void radioButtonQuestion4Answer2(View view){
        RadioButton radioButtonQuestion4Answer2 = (RadioButton) findViewById(R.id.rb_question4_answer2);
        radioButtonQuestion4Answer2.setChecked(true);
    }
    // set radioButton question 4 answer 3 true
    public void radioButtonQuestion4Answer3(View view){
        RadioButton radioButtonQuestion4Answer3 = (RadioButton) findViewById(R.id.rb_question4_answer3);
        radioButtonQuestion4Answer3.setChecked(true);
    }
    // set radioButton question 4 answer 4 true
    public void radioButtonQuestion4Answer4(View view){
        RadioButton radioButtonQuestion4Answer4 = (RadioButton) findViewById(R.id.rb_question4_answer4);
        radioButtonQuestion4Answer4.setChecked(true);
    }
    // set radioButton question 5 answer 1 true
    public void radioButtonQuestion5Answer1(View view){
        RadioButton radioButtonQuestion5Answer1 = findViewById(R.id.rb_question5_answer1);
        radioButtonQuestion5Answer1.setChecked(true);
    }
    // set radioButton question 5 answer 2 true
    public void radioButtonQuestion5Answer2(View view){
        RadioButton radioButtonQuestion5Answer2 = (RadioButton) findViewById(R.id.rb_question5_answer2);
        radioButtonQuestion5Answer2.setChecked(true);
    }
    // set radioButton question 5 answer 3 true
    public void radioButtonQuestion5Answer3(View view){
        RadioButton radioButtonQuestion5Answer3 = (RadioButton) findViewById(R.id.rb_question5_answer3);
        radioButtonQuestion5Answer3.setChecked(true);
    }
    // set radioButton question 5 answer 4 true
    public void radioButtonQuestion5Answer4(View view){
        RadioButton radioButtonQuestion5Answer4 = (RadioButton) findViewById(R.id.rb_question5_answer4);
        radioButtonQuestion5Answer4.setChecked(true);
    }
    // If on click Button check Answers
    public void checkAnswers(View view){
        RadioButton radioButtonQuestion1Answer1 = (RadioButton) findViewById(R.id.rb_question1_answer1);
        if(radioButtonQuestion1Answer1.isChecked()){totalCorectAnswers =totalCorectAnswers+1;
        }
        RadioButton radioButtonQuestion4Answer1 = (RadioButton) findViewById(R.id.rb_question4_answer1);
        if(radioButtonQuestion4Answer1.isChecked()){totalCorectAnswers =totalCorectAnswers+1;
        }
        RadioButton radioButtonQuestion5Answer1 = (RadioButton) findViewById(R.id.rb_question5_answer1);
        if(radioButtonQuestion5Answer1.isChecked()){totalCorectAnswers =totalCorectAnswers+1;
        }
        CheckBox cbQuestionTwoAnswerOne = (CheckBox) findViewById(R.id.cb_question2_answer1);
        CheckBox cbQuestionTwoAnswerTwo = (CheckBox) findViewById(R.id.cb_question2_answer2);
        CheckBox cbQuestionTwoAnswerThree = (CheckBox) findViewById(R.id.cb_question2_answer3);
        CheckBox cbQuestionTwoAnswerFour = (CheckBox) findViewById(R.id.cb_question2_answer4);
        if(cbQuestionTwoAnswerOne.isChecked() && !cbQuestionTwoAnswerTwo.isChecked()&&cbQuestionTwoAnswerThree.isChecked()&&!cbQuestionTwoAnswerFour.isChecked()){
            totalCorectAnswers += 1;
        }
        //compare corect Anser for EditText
        EditText etQuestionThreeAnswerOne = (EditText) findViewById(R.id.et_question3_answer1);
        String etAnswerForQuestion = etQuestionThreeAnswerOne.getText().toString();
        String yearAnswer = etAnswerForQuestion.toString();
        if (yearAnswer.equalsIgnoreCase("1822")){
            totalCorectAnswers =totalCorectAnswers+1;
        }
        String tostMessage;
        boolean checkResult = false;
        EditText nameField = (EditText) findViewById(R.id.edit_text);
        Editable nameEditable = nameField.getText();
        String name = nameEditable.toString();
        tostMessage= "Hi "+name;
        if(totalCorectAnswers == totalQuestions){
            tostMessage = tostMessage+ " Congratulation you have 100% score";
            checkResult = true;
        }else if (totalCorectAnswers > 0){
            tostMessage = tostMessage+" You got "+totalCorectAnswers + " out of "+ totalQuestions;
        }else {
            tostMessage = tostMessage+" all your ansers are incorect  ";
        }
        if(checkResult){
            Toast getMessage = Toast.makeText(this, tostMessage, Toast.LENGTH_LONG);
            getMessage.setGravity(Gravity.BOTTOM, 0, 0);
            getMessage.show();
        }else {
            Toast getMessage = Toast.makeText(this, tostMessage, Toast.LENGTH_LONG);
            getMessage.setGravity(Gravity.BOTTOM, 0, 0);
            getMessage.show();
        }
        // Reset all
        totalCorectAnswers =0;
        nomberCheckBoxTrue= 0;
        RadioGroup rgQuestionOne = findViewById(R.id.rg_question1);
        rgQuestionOne.clearCheck();
        RadioGroup rgQuestionFour = findViewById(R.id.rg_question4);
        rgQuestionFour.clearCheck();
        RadioGroup rgQuestionFive = findViewById(R.id.rg_question5);
        rgQuestionFive.clearCheck();
        CheckBox chbQuestionTwoAnswerOne = findViewById(R.id.cb_question2_answer1);
        chbQuestionTwoAnswerOne.setChecked(false);
        CheckBox chbQuestionTwoAnswerTwo = findViewById(R.id.cb_question2_answer2);
        chbQuestionTwoAnswerTwo.setChecked(false);
        CheckBox chbQuestionTwoAnswerThree = findViewById(R.id.cb_question2_answer3);
        chbQuestionTwoAnswerThree.setChecked(false);
        CheckBox chbQuestionTwoAnswerFour = findViewById(R.id.cb_question2_answer4);
        chbQuestionTwoAnswerFour.setChecked(false);
        EditText etQuestioThreeAnswer1 =findViewById(R.id.et_question3_answer1);
        etQuestioThreeAnswer1.setText("");
        Button btCheckResultTotal = findViewById(R.id.checkResult);
        btCheckResultTotal.setEnabled(true);
    }
}